<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">US Trademark Services</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">US Trademark Services</h4>
                                <p style="text-align: justify;">A federal trademark registration through United States Patent & Trademark Office provides valuable protection to a trademark in the United States, but that protection only extends as far as the goods and services that were originally set forth in the trademark application. Correctly describing these goods and services and rightly placing them in the correct "class" is a vital part of securing your trademark rights.</p>
                                <p style="text-align: justify;">Properly identifying the goods and services that you intend to associate with any proposed trademark is of significant importance and is best done by an experienced trademark attorney to avoid any future litigations. Remember that a trademark is a brand name that you want to use to designate and distinguish your goods and service from those of your competitors. But the scope of protection of a federal registration of that trademark is only applicable to the specific international class and the goods and services that you designate and pay for in your trademark application. We, at NYBACS, can help you register your trademark or brand name with USPTO with dueful diligence by our experienced trademark attorneys.</p>
								<p style="text-align: justify;">US applicants (both entities and individuals) do NOT need attorney-on-record to submit their trademark application.  To start the process, you can make the payment here <a href= "https://buy.stripe.com/8wM8yRbVZ2201i000t" style="color:blue;"> here</a> and email us the screen shot of your payment, and our trademark team will get in touch with you in one business day to take forward the process.</p>
								<p style="text-align: justify;">Non-US appilcants (both entities and individuals) would need a registered US trademark attorney to submit their application.  To start your process, you can make the payment here <a href= "https://buy.stripe.com/14kaGZ5xBeOM6CkeVk" style="color:blue;"> here</a> and email us the screen shot of your payment, and our trademark team will get in touch with you in one business day to take forward the process.  To know more about our US trademark services or its pricing, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>.</
								
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>