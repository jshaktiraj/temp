<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">FAQs</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">Frequent Asked Questions</h4>
                                                                <p style="text-align: justify;">Can a non-US citizen open a company in the US?
<br>Yes, definitely but would need the services of a professional to do the same.<br /></p>
                               
                                                                <p style="text-align: justify;">Do we need a US visa or a partner to open a company in the US?

<br>No, it is not required.<br /></p>
                               
                                                                <p style="text-align: justify;">Do we have to visit the US physically to open a company there?

<br>No, your physical presence is not required.  We can do it at the comfort of your home or office.<br /></p>
                               
                                                                <p style="text-align: justify;">When we register a company in the US, is it at the federal or state level?

<br>All business entity registrations in the US are at a state level.<br /></p>
                               
                                                                <p style="text-align: justify;">Are you a government-approved agency?

<br>No, we are not.  There is no concept of government approval agencies for company registration.<br /></p>
                               
                                                                <p style="text-align: justify;">What difference does it make if I incorporate in one state to another?

<br>Each US state is governed by its own constitution, so there are differences in documentation required, timeline, fees, state taxes, compliance, yearly filing protocols, dates and so much more.<br /></p>
                               
                                                                <p style="text-align: justify;">Is it very complicated to run a company in the US?

<br>To outsiders, it looks so.  But there are many professionally organized companies likes ours which can ensure total compliance and take care of all the complexities on your behalf.<br /></p>
                               
                                                                <p style="text-align: justify;">We do not have to pay any upfront or advance money for US company registration.  Is it true?

<br>Yes, it is right.<br /></p>
                               
                                                                <p style="text-align: justify;">When do we have to pay your fees?

<br>You pay us only after your company incorporation is done and documents given to us.  You will get an invoice after this, and it should be paid within two days.<br /></p>
                               
                                                                <p style="text-align: justify;">Your US Biz Incorporation fees are the same for all states?

<br>Yes, it is because we have standardized our processes, so that you do not have to worry about any cost rise irrespective of your choice of state for incorporation.<br /></p>
                               
                                                                <p style="text-align: justify;">NDo you take care of all incorporation-related compliances?

<br>Yes, we do.<br /></p>
                               
                                                                <p style="text-align: justify;">Do you provide other ancillary services like accounting, book keeping, tax filing?

<br>Yes, we do.<br /></p>
                               
                                                                <p style="text-align: justify;">Is your team available 24/7?

<br>Mostly, but due to the current nature of the situation around us, there could be situations where our customer service is not available right away.<br /></p>
                               
                                                                <p style="text-align: justify;">Do you pay referral fees?

<br>Yes, we pay a referral fee of $100 for every successful lead submitted by a referrer.<br /></p>
                               
                                                                <p style="text-align: justify;">Do you help in opening a US business bank account too?

<br>Yes, we can help you with this.<br /></p>
                               
                                                                <p style="text-align: justify;">Can you give client references for whom you have opened US entities before?


<br>Yes, definitely.  Please get in touch with us, and we will be happy to provide you.<br /></p>
                               
                                                                <p style="text-align: justify;">Are there any discounts to the fees?

<br>We generally do not offer any discounts but sometimes, on a case by case basis, we do.  Please get in touch with us to know more.<br /></p>
                               
                                                                <p style="text-align: justify;">Which is better - LLC or INC?

<br>It differs on a case by case basis.  Only after receiving full information of your requirement and situation, can this be decided.<br /></p>
                               
                                                                <p style="text-align: justify;">Do you incorporate in other countries too?

<br>Yes, NYBACS can incorporate business entities in any country in the world.<br /></p>
                               
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>