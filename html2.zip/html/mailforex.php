<?php   
$select="new";  
$name=$_POST['name'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$country=$_POST['country'];
$company=$_POST['company'];
$business=$_POST['business'];
$mfi=$_POST['MFI'];    
$cirm=$_POST['CIRM'];   
$cfcf=$_POST['CFC']; 
// $state=$_POST['state'];
// $quirey ="";
require_once ('phpmailer/class.phpmailer.php');
//require_once ('phpmailer/language/phpml.lang-en.php');
$subject="Website Enquiry: $email";
$to="service@nybacs.com";
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = 'ssl';
$mail->Port = 465;
$mail->Username = "service@nybacs.com";
$mail->Password = "Mukeekum!23";
$mail->Host = "smtppro.zoho.in";
$mail->Mailer = "smtp";
$mail->setfrom('service@nybacs.com', "NYBACS");
$mail->AddAddress($to);
$mail->Subject = $subject;
$mail->WordWrap = 80;
$body="<h1>Forex Query</h1>$select\r\n<br/><h3>Person Name:</h3>$name\r\n<br/><h3>Phone Number:</h3>$phone\r\n<br/><h3>Country</h3> $country\r\n<br/><h3>E-mail:</h3> $email\r\n<br/><h3>Company:</h3> $company\r\n<br/><h3>Line Of Business:</h3> $business\r\n<br/><h3>Monthly Foreign Income</h3>$mfi\r\n<br/><h3>Current Inward Remittance Mode</h3>$cirm\r\n<br/><h3>Current Forex Conversion Fees</h3>$cfcf\r\n<br/> ";
$mail->Body = $body;
$mail->IsHTML(true);
if (!$mail->Send()) {?>
<script language="javascript" type="text/javascript">
        alert('Message failed');
        window.location = 'contact-us.php';
    	</script>
<?php } else {?>

<script language="javascript" type="text/javascript">
alert('We have received your request.  Our team will get in touch with you shortly.');
window.location = 'https://nybacs.com/cross-border-payment.php';
</script>



<?php } ?>
























