<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">US EIN/ITIN Assignment</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">US EIN/ITIN Assignment</h4>
                                <p style="text-align: justify;">Whether you are a foreign company or incorporated in US, we can help you get an EIN/ITIN assigned by Internal Revenue Service.  You would need an EIN/ITIN for a variety of reasons.  Although you may not be required to have an EIN/ITIN by law, it is highly recommended for opening up business bank accounts, business loans, building trust with vendors, establishing business credit and more importantly for foreign companies receiving payments from US companies to avoid withholding taxes on your revenue.</p>
								<p style="text-align: justify;">Thanks to our partnership and our own team of  professionals, we can help you receive your EIN/ITIN assigned at cost-effective fees and quicker time frame.  You can avoid risk of registering your business with IRS incorrectly and given that the application process is tedious that requires high knowledge in corporate tax and law, you can depend on our experts who are well trained in corporate classification and IRS regulations. </p>
								
                                <p style="text-align: justify;">To know more about our EIN/ITIN assignment services or if you have a question in your mind about this, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>
								<p style="text-align: justify;">Read our complete <a style="color: #0000ff;" href="https://www.nybacs.com/disclaimer.php">disclaimer</a> here.</p>
                                
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>