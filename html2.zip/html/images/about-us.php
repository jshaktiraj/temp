<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">About Us</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">About Us</h4>
                                <p style="text-align: justify;">New York Business Advisory & Corporate Services Inc. (NYBACS) is a full-service US-headquartered Global Business Advisory and Corporate Services company with presence in multiple geographies. We provide Business Advisory, Incorporation, Factoring Services, and Cross-Border Payment Solutions to clients across the world with a special focus to help small & medium businesses expand internationally. Our global network of attorneys and industry professionals make it easy for every business; be it business expansion or a new project or for any requirement of your business.</p>
                                <p style="text-align: justify;">NYBACS is a private corporation, founded in 2020 by professionals with decades of diverse international experience.  Unlike other companies in our business, NYBACS never believes in "one-size-fit-all" solution and always has a high level of interaction with clients, both pre and post incorporation, to discuss requirements in detail and advise the best possible solution from time to time and take care of every small detail with a single interaction window.  We never collect any advance or upfront money from clients.  There are never any hidden fees or surprises later – all of our fees are transparent and built into our pricing and informed to clients before hand.</p>
                                
                                 <h4 class="about-content-title">Our Partners</h4>
                                <p style="text-align: justify;">NYBACS has teamed with organizations to provide its clients with some of the best innovative solutions and closely works with them to deliver the best.  Our Partners bring a lot of value proposition to our clients and thereby serving as a key differentiator to our service offerings.  Below are some of the organizations that NYBACS is proudly partnered with.</p>
                                
                                <p style="text-align: justify;">We, at NYBACS, place great value on the relationships we have with our partners. Whether actively participating in our marketing programs or by assisting our clients on the backstage, there are numerous ways which our partners can forge win-win relationships with NYBACS. For further information and to find out how your organization can get involved, and begin a long and mutually beneficial relationship with NYBACS, please click <a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>
                               
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       


            <div class="container">
               <div class="col-sm-12 col-md-12">
                   <div class="row"> 
                      <div align="left" style="padding-bottom:40px;;">
                      <a href= "https://stenn.com/" >
                        <img src="images/footerlogos/sten.jpg" width="90" class="footer-logo">
                        <a href= "https://t-hub.co/stakeholders/service-providers/" >
                        <img src="images/footerlogos/t-hub.jpg" width="89"  class="footer-logo">
                        <a href= "http://tracking.payoneer.com/SH31t" >
                        <img src="images/footerlogos/Payoneer.jpg" width="170" class="footer-logo2">
                        <a href= "https://www.factoring.org/vendor_details.asp?ID=6114">
                    <img src="images/footerlogos/IFA.jpg" width="170" class="footer-logo2">
                    </div>
                   </div>
                </div>
            </div>




        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>