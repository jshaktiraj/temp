<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">Global Business Incorporation</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">Global Business Incorporation</h4>
                                <p style="text-align: justify;">NYBACS is perhaps one of very few companies in the world who can help you incorporate your company in any country or region, from Bulgaria to Japan to Ghana, just any country except of course those countries where US-mandated sanctions apply.</p>
								<p style="text-align: justify;">Incorporation in every country is unique and our team of professionals has mastered this domain with several years of experience.  We ensure all legal compliance and requirements are in place for your business to be incorporated and run smoothly.  We guarantee minimal documentation and simple process so as to not make you go around and waste time and money when it is not needed to be.  We have served 100s of customers with 100% satisfaction and as a general policy, we collect fees from our clients only after the work is complete – this is unprecedented and no other company offers this feature anywhere.</p>
								<p style="text-align: justify;">Each country and region has different set of requirements, eligibility, and fees.  So, to receive more information about our Global Business Incorporation services or if you have a question in your mind about this, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>.</
								
								
                               
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>