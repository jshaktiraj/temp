<?php   
$select=$_POST['subject'];                                               
$name=$_POST['name'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$city=$_POST['city'];
$country=$_POST['country'];
$select=$_POST['timezone'];   
// $state=$_POST['state'];
// $quirey ="";
require_once ('phpmailer/class.phpmailer.php');
//require_once ('phpmailer/language/phpml.lang-en.php');
$subject="Website Enquiry: $email";
$to="service@nybacs.com";
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = 'ssl';
$mail->Port = 465;
$mail->Username = "service@nybacs.com";
$mail->Password = "Mukeekum!23";
$mail->Host = "smtppro.zoho.in";
$mail->Mailer = "smtp";
$mail->setfrom('service@nybacs.com', "NYBACS");
$mail->AddAddress($to);
$mail->Subject = $subject;
$mail->WordWrap = 80;
$body="<h1>Customer Query</h1><h3>Subject:</h3>$select\r\n<br/><h3>Person Name:</h3>$name\r\n<br/><h3>Phone Number:</h3>$phone\r\n<br/><h3>City:</h3>$city\r\n<br/><h3>Country</h3> $country\r\n<br/><h3>E-mail:</h3> $email\r\n<br/>";
$mail->Body = $body;
$mail->IsHTML(true);
if (!$mail->Send()) {?>
<script language="javascript" type="text/javascript">
        alert('Message failed');
        window.location = 'contact-us.php';
    	</script>
<?php } else {?>

<script language="javascript" type="text/javascript">
alert('Your form has been Submitted. We will contact you soon.');
window.location = 'https://nybacs.com/contact-us.php';
</script>



<?php } ?>
























