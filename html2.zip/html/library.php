<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">LIbrary</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">Doing Business In US</h4>
                                <p style="text-align: justify;">A Primer On Doing Business In The United States </p>
								<p style="text-align: justify;">As the country with the world’s largest economy, the United States offers some of the best business opportunities in the world. To assist businesses in taking advantage of those opportunities, this guide provides an overview of the US legal system and some of the laws relevant to doing business in the US </p>
								<p style="text-align: justify;"><strong>United States Legal System:</strong> The United States has a federal system of government. This means that laws are made at the national (federal), state, and local levels. “Local” laws are those made by citie and counties that apply in those geographic regions. All 50 states (along with US territories and the District of Columbia) have their own state and local laws that apply in those jurisdictions. Some areas of law, such as patent and copyright, are governed exclusively by federal law. Many other laws, including laws governing contracts, employment relationships, and sales transactions, are primarily set by individual states. And many other areas of law are governed by both federal and state law. When doing business in the US, foreign companies should be aware that they are subject to these parallel systems of laws which often differ from state to state. </p>
								<p style="text-align: justify;"><strong>Entity Choice:</strong> A foreign company entering the US must decide on the form of business entity it will use to conduct its US operations. The most common types of domestic business entities are corporations, limited liability companies (LLCs), and partnerships. Each business form has its own benefits and the choice of form depends on case-specific legal and business factors. Each type of business entity must be formed according to the laws of the state in which the entity is formed. All entity types other than partnerships require organizing documents to be filed with the state government. </p>						
								<p style="text-align: justify;"><strong>Branch Office:</strong> A foreign company is not required to conduct business in the US through a US entity and could instead open a branch office. Doing so, however, is generally not advised for tax and liability reasons. A branch office, unlike a subsidiary, is not a separate legal entity of the parent company. A branch office is considered to be the foreign company operating in the US. If a foreign company establishes a branch office in the US and conducts business in the US, the entire company is considered to be “doing business” in the US. This can subject the company to taxation on all income earned, rather than limiting taxation to the income of the branch office. Furthermore, liability of the foreign company would not be limited to liability incurred at the branch level. Accordingly, foreign businesses coming to the US do not generally elect to open a branch office unless specifically advised to do so by a US attorney. Selecting one of the entity forms discussed below is typically more advantageous than opening a branch office. </p>
								<p style="text-align: justify;"><strong>Corporations:</strong> Many foreign companies do business in the US as corporations. Corporations are organized under state law and each state has its own rules for creating and operating corporations. In the US a corporation may be created under the laws of one state and have its principal place of business in a different state. A logical choice is to incorporate in the state where the business intends to locate its operations. The state of Washington is popular choice for business to incorporate in due to predictable and business-friendly laws. The Washington Uniform Business Organizations Code and the Washington Business Corporation Act govern the formation of a Washington corporation. </p>
								<p style="text-align: justify;">To form a corporation, a certificate of incorporation must be filed with the Secretary of State— typically online—in the chosen state. In most states, the owners (also called “shareholders”) of a corporation elect directors, who set company policy and elect officers, such as a company president, vice president, secretary, and treasurer. The directors of a US corporation can be foreign nationals and must be natural persons and not foreign companies. The rules for operating the corporation are commonly included in the company’s written bylaws. The internal structure and bylaws of corporations are similar across jurisdictions but can be customized to meet individual company needs. </p>
								<p style="text-align: justify;">The most common corporate form is called a C-corporation. C-Corporations are taxed at the corporate income tax rate separate from the company’s owners. This means that profits distributed as payments to the owners are taxed twice—first at the corporate level and second at the owner level. This double taxation can be avoided by US companies by electing to be treated as an SCorporation, which is a “pass though” entity for federal tax purposes. A foreign company, however, cannot elect to be treated as an S-Corporation. </p>
								<p style="text-align: justify;">US law treats corporations as legal persons, meaning that a corporation can enter into contracts, sue and be sued, and carry its own liabilities as a natural person does. In general, individual owners can avoid personal liability for the actions of the corporation and, in the event of insolvency, the corporation can declare bankruptcy without putting the owners’ personal assets at risk. It is, however, important for the owners to maintain corporate formalities and keep separation between the owners’ personal affairs and company business in order to prevent creditors from imposing liability on directors and owners personally. Protection from personal liability for directors and owners is among the most important features of a corporation. </p>
								<p style="text-align: justify;"><strong>Limited Liability Companies</strong> Another choice of entity is a Limited Liability Company (LLC). Like a corporation, an LLC is formed by registering with the Secretary of State in the state in which the company is to be created. As with a corporation, an LLC is governed by the laws of the state in which the LLC is formed. An LLC must have at least one member, and members do not need to be natural persons. </p>
								<p style="text-align: justify;">LLCs offer flexibility with respect to how the company can be financed and managed. The owners of an LLC—called “members”—typically design and create an “operating agreement” which governs the operation and organization of the LLC. While most companies elect to create an operating agreement, doing so is optional. For example, under Washington law, members are not required to adopt a written agreement, but without an operating agreement, the LLC will be governed by default provisions set forth by Washington state statutes. Likewise, if the operating agreement leaves out certain provisions, the default provisions of Washington’s LLC law will apply. </p>
								<p style="text-align: justify;">Unlike corporations, LLCs can elect to be taxed as a corporation or to have income “pass through” to members and be taxed at the member level. Many foreign companies prefer to be taxed at the corporate level to avoid having distributions to members reflected on their personal tax returns. </p>
								<p style="text-align: justify;">Like a corporation, an LLC has a legal identity separate from its members. Members’ personal liability is therefore limited to their investments. As with corporations, creditors may only reach members’ personal assets in limited circumstances where the members disregard the separate corporate identity of the company or use the LLC as a shell to avoid liability for a parent company. </p>
								<p style="text-align: justify;"><strong>Partnerships:</strong> A foreign company can also form a partnership by agreeing with another party to do business together in the US. While a written agreement is not required to form a partnership, it is advisable to formalize the arrangement through a written agreement. General partnerships do not offer the same liability benefits as corporations and LLCs. Foreign companies should also know that partnerships can be formed by oral agreement or by conduct without filing any documentation with the state. In some instances, a partnership can be formed unwittingly through an informal agreement to undertake a particular business with another person. Foreign companies should engage counsel early on to avoid these misunderstandings. </p>
								<p style="text-align: justify;"><strong>Banking:</strong> It can be difficult to open a bank account in the US for a foreign entity without a US presence. Even once a foreign individual or company has created a US entity, it is not uncommon for banks in the US to be more willing to lend money to US businesses over their foreign counterparts. Once a foreign business has been successfully doing business in the US for a period of time, that business often has increased access to capital through US banks. </p>
								<p style="text-align: justify;"><strong>Immigration:</strong> All foreigners coming to the US to work must obtain permission to do so in the form of a visa. US visa laws are complicated and strictly federal. Individual states do not regulate or provide visas. Visas are issued by the US embassy or consulate abroad. Many types of visas, including most types of work visas, require approval from US Citizenship and Immigration Services.</p>
								<p style="text-align: justify;">It is important for foreigners to obtain the correct type of visa for their stay in the US. There are numerous employment categories for admission to the US and there are particular categories for investors, for business visitors, and for sponsor-based employment. Many entities bringing a business to the US seek advice from a US immigration attorney to select the correct visa category and to avoid application mistakes. </p>
								<p style="text-align: justify;">Each of the numerous types of visas have different requirements and allow for different authorized lengths of stay in the US. For example, the E-2 non-immigrant visa allows individuals from countries with which the US has a treaty of commerce and navigation to be admitted to the US if the person seeking the visa is investing a substantial amount of capital in a US entity. The individual must be seeking to enter the US solely to develop and direct the investment entity. Separate visas may also  be obtained for employees and family members of qualifying E-2 visa recipients. A qualified individual can stay in the US on an E-2 visa for an initial stay of 2 years and requests for extension of stays may be granted in additional 2-year periods. </p>
								<p style="text-align: justify;">It is critical for foreign business owners and their workers to adhere to the terms of their particular visa as any violation can result in removal from the US or denial of re-entry into the US. </p>
                               
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>