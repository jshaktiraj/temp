<section class="flags">
<div class="container">
 <div class="row" >
 <div class="col-md-9">
  <ul class="flag-main">
   <li class="flag"><img src="images/flags/uk.jpg" width="30"> +1 917-675-5278  </li>&nbsp;&nbsp;&nbsp;&nbsp;
   <li class="flag"><img src="images/flags/united.png" width="30"> +44 208-089-1015  </li>&nbsp;&nbsp;&nbsp;&nbsp;
  <li class="flag"><img src="images/flags/ind.png" width="30"><span class="tel"> +91 905 226 8679</span></li>&nbsp;&nbsp; 
  </ul>
  </div>
<div class="col-md-3">
 <ul class="flag-main">
   <li class="flag"><i class="fa fa-envelope" aria-hidden="true"></i>

 service@nybacs.com</li>&nbsp;&nbsp;
  </ul>
 </div>
</div>
 </div>
</section>
 <hr class="flags">
<div class="header-wrap clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div id="logo" class="logo">
                                <a href="index.php">
                                    <img src="images/nybacs.png" alt="images">
                                </a>
                            </div><!-- /.logo -->
                            <div class="btn-menu">
                                <span></span>
                            </div><!-- //mobile menu button -->
                       
                            <div class="nav-wrap" style="display: none;">                                
                                <nav id="mainnav" class="mainnav">
                                    <ul class="menu"> 
                                        <li class="home">
                                            <a href="index.php" class="active">Home</a>
                                           
                                        </li>
                                      
                                        <li><a href="about-us.php">About Us</a>
                                    
                                        </li>
                                        <li><a href="#">Services</a>
                                            <ul class="submenu"> 
                                                <li><a href="us-biz-incorporation.php">US Business Incorporation </a></li>
                                                <li><a href="ipr-filing.php">IPR Filing </a></li>
                                                <li><a href="go-to-market-services.php">Go-To-Market Services</a></li>
                                                <li><a href="us-incoming-number.php">US Incoming Number</a></li>
												<li><a href="live-phone-answering.php">Live Phone Answering</a></li>
												<li><a href="us-virtual-business-address.php">US Virtual Business Address</a></li>
												<li><a href="us-ein-tax-id-assignment.php">US EIN/Tax ID Assignment</a></li>
												<li><a href="e-verify-empanelment.php">E-Verify Empanelment</a></li>
												<li><a href="us-business-bank-account.php">US Business Bank Account</a></li>
												<li><a href="global-biz-incorporation.php">Global Biz Incorporation </a></li>
												<li><a href="us-business-advisory-services.php">US Business Advisory Services</a></li>
                                                <li><a href="us-eb5-e1-investor-visas.php">US Investor Visa Service</a></li>
                                            </ul><!-- /.submenu -->
                                        </li>
										<li><a href="downloads.php">Downloads</a></li>
										 <li><a href="FAQs_US_Incorporation.php">FAQs</a>
                                    
                                        </li><!-- /.submenu -->
										</li>
                                       <li><a href="contact-us.php">Contact Us</a></li>                                        
                                    </ul><!-- /.menu -->
                                </nav><!-- /.mainnav -->  
                            </div><!-- /.nav-wrap -->
                        </div><!-- /.col-md-9 -->
                        <div class="col-md-6">
                            <div class="nav-wrap" style="float: right;">                                
                                <nav id="mainnav" class="mainnav">
                                    <ul class="menu"> 
                                        <li class="home">
                                            <a href="index.php" class="active">Home</a>
                                            
                                        </li>

                                        

                                        <li><a href="about-us.php">About Us</a>
                                            
                                        </li>
                                         <li><a href="#">Services</a>
                                            <ul class="submenu"> 
                                             
                                                <li><a href="Business-Advisory.php">Business Advisory </a></li>
                                                <li><a href="">US Business Services</a>
                                                               <ul class="submenu"> 
                                                                 <li><a href="us-biz-incorporation.php">US Business Incorporation </a></li>
                                                                 <li><a href="us-ein-tax-id-assignment.php">US EIN/ITIN Assignment</a>
                                                                 </li><li><a href="us-corporate-taxes-1120C-1065-irs.php">US Corporate Tax Filing</a></li>
                                                                 <li><a href="us-business-bank-account.php">US Business Bank Account</a></li>
                                                                 <li><a href="us-trademark-register.php">US Trademark Services</a></li>
                                                                 <li><a href="us-store_front-fda_registration.php">US FDA Registration</a></li>
                                                                 
                                                                 <li><a href="us-eb5-eb1-investor-visas.php">US Visa Services</a></li>

<!--
                                                                 <li><a href="ipr-filing.php">IPR Filing</a></li>
                                                                 <li><a href="go-to-market-services.php">Go-To-Market Services</a></li>
                                                                 <li><a href="us-incoming-number.php">US Incoming Number</a></li>
                                                                 <li><a href="live-phone-answering.php">Live Phone Answering</a></li>
                                                                 <li><a href="us-virtual-business-address.php">US Virtual Business Address</a></li>
                                                                 <li><a href="e-verify-empanelment.php">E-Verify Empanelment</a></li>
                                                                 <li><a href="us-business-advisory-services.php">US Business Advisory Services</a></li>
                                                                 <li><a href="global-business-brokerage.php">Global Business Brokerage </a></li>
-->
                                                             </ul>
                                             
                                             
                                             </li>
                                              <li><a href="">Global Business Services</a>
                                                               <ul class="submenu"> 
                                             <li><a href="global-biz-incorporation.php">Global Business Incorporation </a></li>
                                             <li><a href="global-business-bank-account.php">Global Business Bank Account</a></li>
<li><a href="global_taxation_services.php">Global Taxation Services</a></li>                                             
                                             </ul>
                                                <li><a href="Factoring.php">Factoring </a></li>
                                                <li><a href="cross-border-payment.php">Cross-Border Payments</a></li>

<!--                                                <li><a href="us-biz-incorporation.php">US Biz Incorporation </a></li>-->
<!--
                                                <li><a href="ipr-filing.php">IPR Filing</a></li>
                                                <li><a href="go-to-market-services.php">Go-To-Market Services</a></li>
                                                <li><a href="us-incoming-number.php">US Incoming Number</a></li>
												<li><a href="live-phone-answering.php">Live Phone Answering</a></li>
												<li><a href="us-virtual-business-address.php">US Virtual Business Address</a></li>
												<li><a href="us-ein-tax-id-assignment.php">US EIN/Tax ID Assignment</a></li>
												<li><a href="e-verify-empanelment.php">E-Verify Empanelment</a></li>
                                                <li><a href="us-store_front-fda_registration.php">US FDA Registration</a></li>
												<li><a href="us-business-bank-account.php">US Business Bank Account</a></li>
												<li><a href="global-biz-incorporation.php">Global Business Incorporation </a></li>
-->
<!--
												<li><a href="us-business-advisory-services.php">US Business Advisory Services</a></li>
                                                <li><a href="global-business-brokerage.php">Global Business Brokerage </a></li>
-->
<!--
                                                <li><a href="us-eb5-eb1-investor-visas.php">US Investor Visa Services</a></li>
                                                 <li><a href="">Factoring </a></li>
                                                <li><a href="us-eb5-eb1-investor-visas.php">Taxation</a></li>
-->
                                            </ul><!-- /.submenu -->
                                        </li>
										<li><a href="downloads.php">Downloads</a></li>
										 <li><a href="FAQs_US_Incorporation.php">FAQs</a>
                                    
                                        </li><!-- /.submenu -->
										                                        
                                        <li><a href="contact-us.php">Contact Us</a></li>                                        
                                    </ul><!-- /.menu -->
                                </nav><!-- /.mainnav -->  
                            </div><!-- /.nav-wrap -->
                        </div><!-- /.col-md-3 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->             
            </div><!-- /.header-inner --> 