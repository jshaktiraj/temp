<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">Global Business Bank Account</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">Global Business Bank Account</h4>
                                <p style="text-align: justify;">Opening a business bank account in foreign country for  entrepreneurs who wish to do business there is a great challenge.  Whether you run a small business or you are planning to service your clients in the foreign country, having a local business bank account would increase your clients’ trust and confidence on your company and make it feel local for them. </p>
                                <p style="text-align: justify;">Current banking norms mandate you to pay a personal visit to a bank branch to open a business bank account; however, we, at, NYBACS, will be able to help you open a business bank account in over 200+ countries without a requirement of physical visit.  Your account opening in any country listed below will be taken care by NYBACS through its partner network which has now made it possible for you to open your business bank account in top-tier banks in most countries.  Once the account is opened,  you will be able to operate it to receive and make payments seamlessly and control your accounts remotely from anywhere in the world.</p>
																<p style="text-align: justify;">Another advantage of having a bank account in the country your company is incorporated will be savings on your foreign exchange conversion fees. With eight foreign currency denominations available globally, doing your business using those currencies, and then converting it to your home currency is more affordable and an easier process.</p>
								<p style="text-align: justify;">To know more about our Global Business Bank Account services or if you have a question in your mind about this, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>.</
								
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>