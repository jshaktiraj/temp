<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">US Corporate Tax Filing</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">US Corporate Tax Filing</h4>
                                <p style="text-align: justify;">The United States requires that all corporations file tax returns annually, regardless of whether or not the company was profitable during the tax year with form number 1120 or 1065 as applicable. Corporate tax returns are needed for businesses who have incorporated as either C-corp or S-corp or limited liability company (LLC). Many business owners choose these legal business structures based on their situational requirements.</p>
                                <p style="text-align: justify;">C-corporations pay tax on all profits, minus any deductions. S-corporations and LLCs have the option to choose to be taxed as a corporation or as a partnership where the business is treated as a “pass-through entity” and the profits are passed on to the owner and taxes collected via his or her personal tax returns</p>
								<p style="text-align: justify;">Corporate tax returns are typically due on March 15th each year, however, corporations may request a six-month extension. Any corporations with more than $10 million in assets must file their returns online. An accountant is able to file online on behalf of the business, but the paperwork must be filed electronically. Corporations are able to make installment payments in April, June, September and December.</p>
								<p style="text-align: justify;">Corporate tax returns detail the company’s profits and expenses to determine the amount of tax the company owes to the US government. The return comprises of several schedules that detail information such as the costs of goods sold, dividends and deductions, officer compensation, details about the accounting method used, business type, NAICS classification number, balance sheets, and the reconciliation of income and loss.</p>
								<p style="text-align: justify;">We, at NYBACS, can help you file your US corporate tax returns timely and provide best tax saving solutions where applicable.  Our services are not only cost-effective but also highly reliable as we have an in-house team that works to provide you the best quality service. To know more about our US corporate tax filing services or if you have a question in your mind about this, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>.</
								
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>