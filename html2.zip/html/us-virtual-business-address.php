<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">US Virtual Business Address</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">US Virtual Business Address</h4>
                                <p style="text-align: justify;">New York Business Advisory &amp; Corporate Services offers virtual business addresses at any state in US starting at just $28 a month. You can use your new virtual business address to set up your company in US. We offer world-class customer service coupled with mail box forwarding and exclusive suite numbers that is not shared with anybody else. Our virtual business addresses offer a professional appearance to your company and bring about confidence in your company to your existing and prospective clients. You will receive unlimited digital storage and unlimited recipient coverage from day one, and best part is there is no upfront fees or contracts required and can be canceled any time without any notice period. Look on to our virtual business address to provide you live support and free shredding too.</p>
								<p style="text-align: justify;">Please email <a style="color: #2389f3;" href="mailto:service@nybacs.com" title="mailto:service@nybacs.com" target="_blank" rel="noopener noreferrer" class="_3FXB1 selectable-text invisible-space copyable-text">service@nybacs.com</a> to know more about this or to book your virtual business address in any state in US.</p>
                                
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>