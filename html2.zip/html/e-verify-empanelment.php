<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">E-Verify Empanelment</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">E-Verify Empanelment (CURRENTLY CLOSED)</h4>
                                <p style="text-align: justify;">E-Verify, authorized by Illegal Immigration Reform and Immigrant Responsibility Act of 1996 (IIRIRA), is a web-based system through which employers electronically confirm the employment eligibility of their employees.  While this is NOT mandatory in all states, it is still considered a very useful feature for every employer across US.  Companies can register to participate in E-Verify program by applying to DHS which is generally approved after a thorough verification process.  E-Verify provides you multiple other undocumented benefits too. </p>
                                <p style="text-align: justify;">In the E-Verify process, employers create cases based on information taken from an employee’s Form I-9, Employment Eligibility Verification. E-Verify then electronically compare that information to records available to the U.S. Department of Homeland Security (DHS) and the Social Security Administration (SSA). The employer usually receives a response within a few seconds either confirming the employee’s employment eligibility or indicating that the employee needs to take further action to complete the case. </p>
								<p style="text-align: justify;">E-Verify is administered by SSA and U.S. Citizenship and Immigration Services (USCIS). USCIS facilitates compliance with U.S. immigration law by providing E-Verify program support, user support, training and outreach, and developing innovative technological solutions in employment eligibility verification. </p>
								<p style="text-align: justify;">NYBACS can take care of this process for you end-to-end with the help of our expert professionals who have years of experience in this domain.  We can help your empanelment process for E-Verify for just $460 which needs to be paid only if the application is successful  and only after the work is completed.  To receive more information about the documentation needed to participate in E-Verify program or to apply for one, please email <a style="color: #0000ff;" href="mailto:service@nybacs.com">service@nybacs.com.</a> </p>
                                <p style="text-align: justify;">Read our complete <a style="color: #0000ff;" href="https://www.nybacs.com/disclaimer.php">disclaimer</a> here.</p>
								
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>