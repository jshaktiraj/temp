<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php include('head.php');
	?>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">US FDA Registration</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <!-- Flat about -->
        <div class="flat-row flat-general sidebar-right">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="general about-content">
                            </div><!-- /.about-slider -->

                            <div class="about-content-text">
                                <h4 class="about-content-title">US FDA Registration</h4>
                                <p style="text-align: justify;">As the world’s largest economy and high value and strength of Americal dollar coupled with huge purchasing power parity as well as diverse population from across the world, there is a huge demand for food and cosmetic products from around the world.  Selling your products in US is not just an option any more but a must considering the high margins that you could derive for your business.   We, at NYBACS, always look to make this journey of your business selling products in US an easy and affordable one by offering our US FDA registration service at an affordable rate which is inclusive of US FDA Registered Agent fees and four prior notices.</p>

<p style="text-align: justify;">Requirements before you start selling your food or cosmetic products in US</p>
                                
<p style="text-align: justify;">1.       Any company that manufactures, processes, packs, or stores food, beverages, or health supplements that may be consumed in the U.S. by humans or animals is required to register with the U.S. FDA.</p>

<p style="text-align: justify;">2.       In addition to registering, foreign facilities must designate a U.S. Agent for FDA communication.</p>

<p style="text-align: justify;">3.       Prior Notice: It is an advance information filed with FDA for each shipment before it arrives in USA.</p>

<p style="text-align: justify;">All of the above is taken care by NYBACS US team with utmost regard to rules and regulalations.</p>

<p style="text-align: justify;"> NYBACS can also provide store front/logistics solutions within US so that you receive all the services under one roof which means you do not have to go to multiple vendors before you start selling your products in US.  Please note that services of a US store front are ONLY available for US incorporated companies.

We also offer a complete US Product Sell package at just $1999 that includes everything that is needed for you to start selling your food or cosmetic products in US.  To know in detail about our US FDA or US Store Front Services or if you have a question in your mind about this, do not hesitate to reach out to us by clicking<a href= "https://nybacs.com/contact-us.php" style="color:blue;"> here.</a></p>


                                
                            </div><!-- /.about-content-text -->
                       
                                    </div><!-- /.widget_text -->
                                </div><!-- /.sidebar -->
                            </div><!-- /.sidebar-wrap -->
                        </div><!-- /.general-sidebar -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-about -->
       
        <!-- Footer -->
        <footer class="footer">
            <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-countTo.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>  
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>