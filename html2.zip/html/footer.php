       
                <div class="container">
                    <div class="row"> 
                        <div class="flat-wrapper">
                            <div class="ft-wrapper" style="display: none;">
                                <div class="footer-70">
                                    <div class="widget widget_text">            
                                        <div class="textwidget">
                                            <div class="custom-info">
                                                <span>Have any questions?</span>
                                                <span><i class="fa fa-reply"></i>info@gmail.com</span> 
                                                <span><i class="fa fa-map-marker"></i>66 Nicholson St Buffalo New York US</span> 
                                                <span><i class="fa fa-phone"></i>1 800 232 3485</span>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- /.col-md-10 -->

                                <div class="footer-30">
                                    <div class="widget widget_text">            
                                        <div class="textwidget">
                                            <div class="logo-ft"><img src="images/logo-ft.png" alt="logo"></div>
                                        </div>
                                    </div>
                                </div><!-- /.col-md-2 -->
                            </div><!-- /.ft-wrapper -->
                        </div><!-- /.flat-wrapper -->
                    </div><!-- /.row -->    
                </div><!-- /.container -->
            </div><!-- /.footer-widgets -->

            <div class="footer-widgets">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="widget widget_text">            
                                <div class="textwidget">
                                    <h3 style="color: #fff;text-align: center;">About Us</h3>
                                    <p style="text-align: justify;">New York Business Advisory & Corporate Services Inc. is a NY-headquartered Global Business Advisory and Corporate Services company with presence in multiple geographies.  We offer Business Advisory, US & Global Business Incorporation Services, Factoring, and Cross-Border Payment Solutions to clients globally. </p>
                                    
                                </div>
                            </div>
                        </div><!-- /.col-md-4 -->
                    <h3 style="text-align: center;color: #fff;">Quick Links</h3>
                        <div class="col-md-4">
                            <div class="widget widget_nav_menu">
                                <div class="menu-footer-menu-container">
                                    <!--<h3 style="color: #fff;">Quick Links</h3>-->
                                    <ul class="ft-menu">
                                        <li><a href="index.php">Home</a></li>
                                        
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="Business-Advisory.php">Business Advisory</a></li>
                                        <li><a href="us-biz-incorporation.php">US Business Incorporation</a></li>
                                        <li><a href="us-ein-tax-id-assignment.php">US EIN/ITIN Assignment</a></li>
										<li><a href="/us-business-bank-account.php">US Business Bank Account</a></li>
										<li><a href="us-corporate-taxes-1120C-1065-irs.php">US Corporate Tax Filing</a></li>
										<li><a href="us-trademark-register.php">US Trademark Services</a></li>
										
										
                                        
                                    </ul>
                                </div>
                            </div>
                        </div><!-- /.col-md-4 -->

                        <div class="col-md-4">
                            <div class="widget widget_nav_menu">
                                <div class="menu-footer-menu-container">
                                    <ul class="ft-menu">
                                               
												<li><a href="downloads.php">Downloads</a></li>
						
												<li><a href="contact-us.php">Contact Us</a></li>
                                                
												<li><a style="font-size: 13px;" href="Factoring.php">Factoring</a></li>
                                                <li><a style="font-size: 13px;" href="cross-border-payment.php">Cross-Border Payments</a></li>
                                               <li><a href="us-eb5-eb1-investor-visas.php">US Visa Services</a></li>
												<li><a style="font-size: 13px;" href="us-store_front-fda_registration.php">US FDA Registration</a></li><li><a style="font-size: 13px;" href="global-biz-incorporation.php">Global Business Inc</a></li><li><a style="font-size: 13px;" href="global-business-bank-account.php">Global Business Bank A/C</a></li>
                                                
												
                                    </ul>
                                </div>
                            </div>
							
                        </div><!-- /.col-md-4 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.footer-content -->


            <div class="footer-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="social-links">
							
                               
								<a href="https://twitter.com/NYBACS">
                                    <i class="fa fa-twitter"></i>
                                </a>
								<a href="https://www.facebook.com/Nybacs-106948664317467/">
                                    <i class="fa fa-facebook-official"></i>
                                </a>
								
								 <a href="https://www.linkedin.com/company/business-incorporation-services-llc-inc-us-uk-australia/?viewAsMember=true">
                                    <i class="fa fa-linkedin" style="background: #008ec1;"></i>
                                </a>
								
                                <!--
                                <a href="#" target="_blank">
                                    <i class="fa fa-google-plus"></i>
                                </a>-->
                            </div>
                        </div><!-- /.col-md-12 -->
                        <div class="col-md-12">
                            <div class="copyright">
                                <div class="copyright-content">
                                    Copyright © 2022 New York Business Advisory & Corporate Services Inc.</a> </div>    <a href="terms-and-conditions.php">Terms & Conditions</a>   <a href="privacypolicy.php">  |  Privacy Policy</a><a href="disclaimer.php">  |  Disclaimer</a></li>
                                    <script type="text/javascript">
_linkedin_partner_id = "1012651";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(l) {
if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
window.lintrk.q=[]}
var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})(window.lintrk);
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=1012651&fmt=gif" />
</noscript>
                                </div>
                            </div>
                        </div><!-- /.col-md-12 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.footer-content -->