<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     <?php include('head.php');
	?>
	<style>
p
{text-align: justify;
}
	</style>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
         <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
             <?php include('menu-bar.php');
	?>
        </header>
        <!-- /.header -->

        <!-- Page title -->
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    <li class="trail-end">Disclaimer</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->

        <div class="flat-row pad-bottom0px">
            <div class="container">
                <div class="row">
                    <div class="flat-wrapper">
                        <div class="flat-services">
                           
                                    </div>
                                </div>
                            </div><!-- /.slotholder -->

                            <div class="flat-divider d50px"></div>

                            <div class="services-title">
                          
                            </div>

                            <div class="flat-divider d50px"></div>

                            <div class="services-content clearfix">
                                    
									<p>CAREFULLY READ THE FOLLOWING TERMS AND CONDITIONS BEFORE USING THIS WEBSITE OR ANY OF ITS PRODUCTS OR SERVICES. THE PRODUCTS AND SERVICES OFFERED ON THIS WEBSITE WWW.NYBACS.COM HAVE BEEN DEVELOPED, PROVIDED, AND/OR ARE LICENSED BY NEW YORK BUSINESS ADVISORY & CORPORATE SERVICES INC., ITS CONTRACTORS, AGENTS, EMPLOYEES, OFFICERS, DIRECTORS AND AFFILIATES (HEREINAFTER COLLECTIVELY REFERRED TO AS "NYBACS" OR “WE”), FOR YOUR USE ONLY AS SET FORTH BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT, DO NOT USE THE PRODUCTS OR SERVICES. USING ANY PART OF THE PRODUCTS OR SERVICES INDICATES THAT YOU ACCEPT THESE TERMS. THIS AGREEMENT APPLIES TO YOU, YOUR AGENTS AND EMPLOYEES, AND YOUR ASSIGNS (HEREINAFTER COLLECTIVELY REFERRED TO AS "YOU").</p>
                                    <p>WE ARE A PRIVATE SERVICE. WE ARE NOT ASSOCIATED WITH ANY FEDERAL, STATE OR COUNTY GOVERNMENT AGENCY OR DEPARTMENT.</p>
                                    <p><strong>NO WARRANTY OR REPRESENTATION:</strong> THE PRODUCTS AND SERVICES OFFERED BY NYBACS ARE PROVIDED AS-IS WITH NO WARRANTIES OR REPRESENTATIONS, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, WARRANTY THROUGH COURSE OF DEALING, FITNESS FOR A PARTICULAR PURPOSE. NO WARRANTY OR REPRESENTATION SHALL BE CREATED AS A RESULT OF ANY INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM NYBACS. NOTHING CONTAINED HEREIN OR PROVIDED BY NYBACS SHALL BE DEEMED TO BE LEGAL OR BUSINESS ADVISE WITH RESPECT TO ANY MATTER. THE TERMS, CONDITIONS AND OPERATION OF THIS WEB SITE MAY CHANGE AT ANYTIME.</p>
                                    <p>NYBACS SHALL NOT BE LIABLE FOR INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF ANY KIND, LOSS OF BUSINESS OR INCOME, OR OTHER FINANCIAL OR ANY OTHER LOSSES ARISING OUT OF OR IN CONNECTION WITH THE SALE OR USE OF ANY PRODUCTS OR SERVICES, WHETHER BASED IN CONTRACT, TORT (INCLUDING NEGLIGENCE) OR ANY OTHER THEORY, EVEN IF NYBACS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. NYBACS'S ENTIRE LIABILITY SHALL BE LIMITED, AT NYBACS’S OPTION, TO THE REPLACEMENT OR REPAIR OF THE PURCHASED PRODUCT, OR REFUND OF THE COST OF SALE, PRODUCT OR SERVICE PURCHASE PRICE PAID.</p>
                                    <p><strong>NO LEGAL SERVICES:</strong> Neither NYBACS nor its officers, representatives or employees are attorneys nor is any of them is in the business of providing legal services or advice. NYBACS warns, cautions and encourage you to consult an attorney with respect to any and all applicable legal matters, including, without limitation, matters relating to the corporate, business and tax laws in your jurisdiction(s) that may apply to you and to the entity/entities which you are considering forming. The products and services of NYBACS are provided solely as an administrative convenience, not as a substitute for the retainer and consultation of a knowledgeable attorney with respect to any and all matters concerning all applicable laws and their interpretation. You agree that you will consult with an attorney with respect to any legal matter including but not limited to matters relating to the corporate, business and tax laws in your jurisdiction(s) that may apply to you and to the entity/entities which you are considering forming. You agree that you will not rely on any information on this website or otherwise provided by us as accurate or as legal or business advice. NYBACS does not warrant the accuracy of any such statements. Any information on this website must not be construed as legal information and is solely provided for ease of reference and is not represented as being up to date. Additionally, any legal information contained herein is subject to the laws of varying jurisdiction and the interpretation of various courts.</p>
                                    <p><strong>OWNERSHIP OF MATERIALS:</strong> To the full extent permitted by law, the content, words, text, forms, designs, and expressions of ideas on this Website (collectively the "Materials”) are the exclusive property of NYBACS, and are protected by applicable copyright, trademark, patent and intellectual property laws. NYBACS grants to you a limited, nonexclusive license to use any Materials that are purchased and downloaded by you, subject to the terms and restrictions set forth in this Agreement. You are not permitted to use the Materials in any manner not expressly authorized by this Agreement. You will not make the Materials available for distribution, publication, or re-sale to any third party. You acknowledge and agree that ownership of the Materials and all subsequent copies thereof regardless of the form or media, remains with NYBACS or its suppliers. You further agree not to engage in any “reverse engineering” of any of NYBACS’s systems or other items incorporated on this website to provide the products and services offered by NYBACS.</p>
                                    <p><strong>THIRD PARTY VENDORS:</strong> NYBACS may permit third party vendors to advertise and sell products or services through this and other websites. You agree that NYBACS makes no warranty, representation, or endorsement with respect to such products or services and will not be responsible for any transactions or occurrences with respect to such third party vendors.</p>
                                    <p><strong>COMPUTER PROBLEMS:</strong> You agree that you are using this website at your own risk and will indemnify and hold NYBACS harmless with respect to any damage that may be caused to your computer, data, programs, or any other property or business, as a result of using or downloading of materials, data, or viruses that could originate with this website. NYBACS uses secure servers with encrypted data to assure the confidentiality of financial data. You agree that NYBACS will not be held liable for unauthorized interceptions of E-mail or other transmissions that are sent between the parties, nor unauthorized access to our servers and/or service or “hacking” of our servers and/or service. You further agree to hold NYBACS harmless from any damage(s) incurred by you or by your affiliates as a result of your connection to our servers and service, including, but not limited to, when such damage is incurred as a result of an error in the server(s) or service and/or when such damage is incurred or a result of a hacker or other unauthorized access to our server(s) and/or service</p>
                                    <p><strong>EXCLUSIVE REMEDIES, LIMITATION OF LIABILITY:</strong> Should NYBACS supply a defective product or negligent service and you notify NYBACS in writing within one (1) week thereof, your sole and exclusive remedy shall be, at NYBACS's sole option, to repair or replace the product or service. If NYBACS cannot reasonably repair or replace the product or service then NYBACS may, in its sole discretion, refund the price paid for the product or service. NYBACS will have no obligation to provide any other or additional remedies or compensation.</p>
                                    <p><strong>REGISTERED AGENT:</strong> Should you choose to have NYBACS as your new entity’s/entities’ registered agent, you are required to supply NYBACS with your accurate contact information. You understand and agree that by law, as “registered agent” NYBACS may be served in your place for any and all lawsuits, and/or other legal process, against you and that such service of process, served upon us, will be legally binding upon you. You further understand and agree that a failure by you to maintain and update your contact information with us may result in our inability to advise you of legal process or other papers served upon us as your registered agent. You acknowledge and agree that NYBACS will have no responsibility to you should NYBACS be unable to inform you of any papers received by NYBACS on your behalf, if our inability to contact you is as a result of your failure to supply and maintain accurate contact information with NYBACS.
                                    <p><strong>THIRD PARTY DESIGNEE:</strong> New York Business Advisory & Corporate Services Inc. is a private company that provides paid assistance in preparing and filing documents and interacting as a Third Party Designee with the government agencies like IRS, DHS, USCIS, other government agencies, on behalf of its customers. We are not affiliated with nor endorsed by the Internal Revenue Service (IRS), Dept. of Homeland Security, United States Council for Immigration Services, other government agencies. It is possible to apply for an EIN, E-Verify Empanelment, few other services free of charge at <a style="color: #0000ff;" href="http://irs.gov">www.irs.gov</a>, <a style="color: #0000ff;" href="http://e-verify.gov">www.e-verify.gov</a> and other official government websites. We do not review any applications from a legal standpoint. The use of our services is subject to its Terms and Conditions.</p>
									<p><strong>DISCLAIMER:</strong> Some jurisdictions do not allow the exclusion or limitation of implied warranties or the limitation of incidental or consequential damages so the above limitations and exclusions may be limited in their application to you. When implied warranties may not be excluded in their entirety, such implied warranties will be limited to the full extent permitted by the laws of such jurisdictions.</p>
                                    <p><strong>DISCHARGE, RELEASE, AND WAIVER:</strong> In consideration of your use of this website and/or any services or products offered hereunder, you agree, except as specifically provided herein, to forever waive, discharge, and release, and waive NYBACS of all claims, causes of action, damages, and demands whatsoever, in law, admiralty or equity, which you ever had, now have or hereafter can, shall or may, have against NYBACS for, upon, or by reason of any matter, cause or thing whatsoever from the beginning of the world to the end of time.</p>
                                    <p><strong>GOVERNING LAW:</strong> This Agreement is being entered into and shall be construed in accordance with the laws of the State of Florida as if it were executed in, and to be wholly performed in the State of Florida. You consent and submit to the exclusive jurisdiction of the State of Florida and federal and state courts having jurisdiction in Palm Beach County in the State of Florida. You hereby expressly and irrevocably waive any objection to jurisdiction and venue in Palm Beach County, Florida including, but not limited to, objections based upon inconvenient forum. This Agreement shall be governed by the laws of the State of Florida and by the laws of the United States, excluding their conflicts of laws principles. The United Nations Convention on Contracts for the International Sale of Goods is hereby excluded in its entirety from the application to this Agreement.</p>
                                    <p><strong>SEVERABILITY:</strong> In the event any provision of this Agreement is found to be invalid, illegal or unenforceable, the validity, legality and enforceability of any of the remaining provisions shall not in any way be affected or impaired.</p>
                                    <p style="margin-bottom: 50px;"><strong>ENTIRE AGREEMENT:</strong> This Agreement sets forth the entire agreement between you and NYBACS, supersedes all prior agreements, whether written or oral, with respect to the subject matter contained herein, and may be amended only in a writing signed by both parties.</p>

                                </div>

                                
                            </div><!-- /.services-content -->

                            <div class="flat-divider d50px"></div>


                        </div><!-- /.flat-services -->
                    </div><!-- /.flat-wrapper -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-row -->

                            </div><!-- /.item-three-column -->

                            </div><!-- /.item-three-column -->

                            </div><!-- /.item-three-column -->
                        </div><!-- /.flat-imagebox -->
                    </div><!-- /.flat-wrapper -->                    
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-row -->

                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-row -->
       
        <!-- Footer -->
        <footer class="footer">
             <?php include('footer.php');
	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/parallax.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>

</html>