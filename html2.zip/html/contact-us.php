<!DOCTYPE html>
<html lang="en-US">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <?php include('head.php');
	?>
	<style>
	     .form-control{
	         background: #d8e7ef;
	     }
	</style>
</head>                                 
<body class="header-sticky page-loading">   
    <div class="loading-overlay">
    </div>
    
    <!-- Boxed -->
    <div class="boxed">
        <?php include('top-bar.php');
	?>
        </div><!-- /.top -->

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <?php include('menu-bar.php');
	?>
        </header><!-- /.header -->

         <div class="page-title style1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <div class="breadcrumbs">
                                <ul class="trail-items">
                                    <li>You are here:</li>
                                    <li class="trail-item"><a href="index.php">Home</a></li>
                                    
                                    <li class="trail-end">Contact Us</li>
                                </ul>                   
                            </div>
                        </div><!-- /.page-title-captions -->                        
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div>

        <div class="flat-row parallax parallax3">
            <div class="overlay bg-f1f2f8"></div>
            <div class="container">
                <div class="row">
                    <div class="flat-wrapper">
                        <div class="flat-iconbox clearfix">
                            <div class="item-three-column">
                                <div class="iconbox">
                                    <div class="box-header">
                                        <div class="box-icon">
                                            <img src="images/Newyork.jpg">
                                            <!--<i class="fa fa-map-marker"></i>-->
                                        </div>
                                        <h5 class="box-title">UNITED STATES</h5>
                                    </div>
                                    <div class="box-content">
                                        <p>99 Wall Street Ste 1079<br>New York, NY 10005<br>
                                        +1 917-675-5278
                                        </p>
                                        <!--<p>Try our self service options. Available 24/7</p>
                                        <p>
                                            <strong>Online Sales:</strong> 1230546970<br>
                                            <strong>Complaints:</strong> 1230546970<br>
                                            <!--<a class="scheme2" href="#">themesflat@gmail.com</a>-->                                   
                                        </p>
                                    </div>      
                                </div><!-- /.iconbox -->
                            </div><!-- /.item-three-column -->

                            <div class="item-three-column">
                                <div class="iconbox">
                                    <div class="box-header">
                                        <div class="box-icon">
                                            <img src="images/London.jpg">
                                            <!--<i class="fa fa-map-marker"></i>-->
                                        </div>
                                        <h5 class="box-title">UNITED KINGDOM</h5>
                                    </div>
                                    <div class="box-content">
                                        <p>86-90 Paul Street<br>London, EC2A 4NE<br>
                                            +044 208-089-1015
                                               
                                        </p>
                                    </div>      
                                </div><!-- /.iconbox -->
                            </div><!-- /.item-three-column -->

                            <div class="item-three-column">
                                <div class="iconbox">
                                    <div class="box-header">
                                        <div class="box-icon">
                                           <img src="images/bengaluru.jpg">
                                            <!--<i class="fa fa-map-marker"></i>-->
                                        </div>
                                        <h5 class="box-title">INDIA</h5>
                                    </div>
                                    <div class="box-content">
                                        
                                        <p>Floor # 22, Brigade WTC Towers <br>Bengaluru, Karnataka 560055
                                            <br>+91 990-026-6900                                              
                                        </p>
                                    </div>      
                                </div><!-- /.iconbox -->
                            </div><!-- /.item-three-column -->
                        </div><!-- /.flat-iconbox -->
                    </div><!-- /.flat-wrapper -->                    
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-row -->

        <div class="flat-row pad-bottom20px">
            <div class="container">
                <div class="row">
                    <h4 style="text-align: center;">Get In Touch with Us</h4>
                    
                        <div class="flat-divider d20px"></div>
                        <form method="post" action="mail.php">
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-6">
                                                                        
                                        <select name="subject" style="width: 100%;">
                                        <option>Select Your Interest</option>
                                        <option>Business Advisory</option>
										<option>US Business Incorporation</option>
										<option>US EIN/ITIN Assignment</option>
                                        <option>US Corporate Tax Filing</option>                                     							                                      
										<option>US Business Bank Account</option>
                                        <option>US Trademark Services</option>
                                        <option>US FDA Registration</option>
                                                                               
                                        <option>Global Business Incorporation</option>
                                        <option>Global Business Bank Account</option>
										<option>Global Taxation Services</option>
										<option>Factoring</option>
										<option>Cross-Border Payment Solutions</option>
										<option>Partnering with NYBACS</option>
                                        <option>Others</option>
                                        </select>
                                        <br><br>
                                        
                                        
                                    <span><input name="name" type="text" value="" placeholder="Name" required="required"></span><br><br>
                                    <span><input  name="phone" type="text" value="" placeholder="Phone Number" required="required"></span><br><br>
                                    <span><input  name="email" type="email" value="" placeholder="Email" required="required"></span><br><br>
                                    <span><input  name="city" type="text" value="" placeholder="City" required="required"></span><br><br>
                                    <span><input  name="country" type="text" value="" placeholder="Country" required="required"></span><br><br>
                                     <select name="timezone" style="width: 100%;">
                                        <option>Preferred Time Zone For Call Back</option>
                                        <option>Greenwich Mean Time</option>
										<option>Universal Coordinated Time</option>
										<option>European Central Time</option>
										<option>Eastern European Time</option>
										<option>Egypt Standard Time (Arabic) </option>
										<option>Eastern African Time</option>
										<option>Middle East Time</option>
										<option>Near East Time</option>
										<option>Pakistan Lawhore Time</option>
										<option>India Standard Time </option>
                                        <option>Bangladesh Standard Time</option>	
                                        <option>Vietnam Standard Time</option>
                                        <option>Eastern European Time</option>
										<option>China Taiwan Time</option>
										<option>Japan Standard Time</option>
										<option>Australia Central Time</option>
										<option>Australia Eastern Time</option>
										<option>Solomon Standard Time</option>
										<option>New Zealand Standard Time</option>
                                        <option>Midway Islands Time</option>	
                                        <option>Hawaii Standard Time</option>
                                        <option>Alaska Standard Time</option>
										<option>Pacific Standard Time</option>
										<option>Phoenix Standard Time</option>
										<option>Mountain Standard Time</option>
										<option>Central Standard Time</option>
										<option>Eastern Standard Time</option>
										<option>Indiana Eastern Standard Time</option>
                                        <option>Puerto Rico and US Virgin Islands Time</option>	
                                        <option>Canada Newfoundland Time</option>
                                        <option>Argentina Standard Time</option>
										<option>Brazil Eastern Time</option>
										<option>Central African Time</option>
                                        </select>
                                        <br><br>
                                    
                                    <!-- <span><input  name="state" type="text" value="" placeholder="Best Time to Call" required="required"></span><br><br> -->
                                    <span><input type="reset" value="Reset"></span>
                                        <span><input type="submit" value="Submit">
                                    </span>
                                    
                            </div><!-- /.row -->
                                    <div class="col-md-3"></div>
                                </div>
                        </form>
                    </div><!-- /.col-md-8 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div>
        </div></div></div></div></div></div><!-- /.flat-row -->

        <!-- Footer -->
        <footer class="footer">
            <div class="content-bottom-widgets">        
                <div class="container">
                    <div class="row"></div>
                                <!-- </div>/.col-md-10 -->

                                
                                    <!-- </div> -->
                                <!-- </div>/.col-md-2 -->
                            <!-- </div>/.ft-wrapper -->
                        <!-- </div>/.flat-wrapper -->
                    <!-- </div>/.row     -->
                </div><!-- /.container -->
            </div><!-- /.footer-widgets -->

            <!-- <div class="footer-widgets"> -->
                <?php include('footer.php');	?>
        </footer>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>   

    </div>
    
    <!-- Javascript -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.easing.js"></script> 
    <script type="text/javascript" src="js/jquery-waypoints.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript" src="js/jquery-validate.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript" src="js/gmap3.min.js"></script>
    <script type="text/javascript" src="js/parallax.js"></script>
    <script type="text/javascript" src="js/switcher.js"></script>
    <script type="text/javascript" src="js/smoothscroll.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>

</html>